package br.org.unisenaipr.comercial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComercialApplicationTests {

	@Test
	void contextLoads() {
	}

}
